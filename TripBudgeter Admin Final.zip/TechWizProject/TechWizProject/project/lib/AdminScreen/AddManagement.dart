import 'package:flutter/material.dart';
import 'package:project/AdminScreen/AddHotel.dart';
import 'package:project/AdminScreen/AddPoints.dart';
import 'package:project/AdminScreen/AddResturant.dart';
import 'package:project/AdminScreen/AddServices.dart';
import 'package:project/AdminScreen/AddTicket.dart';
import 'package:project/AdminScreen/Admin.dart';
import 'package:project/AdminScreen/Contacts.dart';
import 'package:project/AdminScreen/ManageTrips.dart';
import 'package:project/AdminScreen/Tickets.dart';
import 'package:project/Components/AdminAppbar.dart';

class AddManagement extends StatefulWidget {
  const AddManagement({Key? key}) : super(key: key);

  @override
  _AddManagementState createState() => _AddManagementState();
}

class _AddManagementState extends State<AddManagement> {
  int selectedIndex = 0;

  final List<String> titles = ["Home","Manage Packages", "Manage Points", "Manage Contacts", "Manage Trips"];
  final List<IconData> icons = [
    Icons.home,
    Icons.airplane_ticket_rounded,
    Icons.bus_alert,
    Icons.phone,
    Icons.campaign,
  ];

  // 👇 Widgets for each tab
  final List<Widget> pages = const [
    Admin(),
    Tickets(),
    AddPoints(),
    Contacts(),
    ManageTrips(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,

      appBar: const AdminAppbar(),
      body: Column(
        children: [
          // Chip Bar
         // Chip Bar
Container(
  color: Colors.white,
  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
  child: Wrap(
    spacing: 8,           // space between chips horizontally
    runSpacing: 12,       // space between chip rows
    alignment: WrapAlignment.start, // left align
    crossAxisAlignment: WrapCrossAlignment.start,
    children: List.generate(titles.length, (index) {
      final bool isSelected = selectedIndex == index;
      return ChoiceChip(
        showCheckmark: false,
        avatar: Icon(
          icons[index],
          size: 20,
          color: isSelected ? Colors.white : Colors.lightBlue,
        ),
        label: Text(
          titles[index],
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.lightBlue,
            fontWeight: FontWeight.w600,
          ),
        ),
        selected: isSelected,
        selectedColor: Colors.lightBlue,
        backgroundColor: Colors.white,
        shape: const StadiumBorder(
          side: BorderSide(color: Colors.lightBlue),
        ),
        onSelected: (_) {
          setState(() {
            selectedIndex = index;
          });
        },
      );
    }),
  ),
),

          const SizedBox(height: 20),

          // Show page content based on selected chip
          Expanded(
            child: pages[selectedIndex],
          ),
        ],
      ),
    );
  }
}
