import 'dart:io';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:another_flushbar/flushbar.dart';
import 'package:project/Components/AdminAppbar.dart';

class AddTicket extends StatefulWidget {
  const AddTicket({Key? key}) : super(key: key);

  @override
  _AddTicketState createState() => _AddTicketState();
}

class _AddTicketState extends State<AddTicket> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final TextEditingController _providerController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();
  final TextEditingController _classController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _departureDateController = TextEditingController();
  final TextEditingController _returnDateController = TextEditingController();
  final TextEditingController _typeController = TextEditingController();

  // Dropdown selections
  String? selectedHotel;
  String? selectedRestaurant;
  String? selectedTransport;

  // Dropdown data maps
  Map<String, String> hotelPackageMap = {};
  Map<String, String> restaurantPriceMap = {};
  Map<String, String> transportPriceMap = {};

  bool isLoading = true;

  // Image Picker
  final ImagePicker _picker = ImagePicker();
  List<File?> selectedImages = [];
  List<Uint8List?> webImages = [];
  final String imgBBApiKey = "90cb66237e5781971422bd58ed770554";

  DocumentSnapshot? updatingDoc;

  @override
  void initState() {
    super.initState();
    fetchDropdownData();
  }

  Future<void> fetchDropdownData() async {
    try {
      QuerySnapshot hotelSnapshot = await FirebaseFirestore.instance.collection('ManageHotel').get();
      hotelPackageMap.clear();
      for (var doc in hotelSnapshot.docs) {
        var data = doc.data() as Map<String, dynamic>;
        hotelPackageMap[data['HotelName'].toString()] = data['Package'].toString();
      }

      QuerySnapshot restaurantSnapshot = await FirebaseFirestore.instance.collection('ManageRestaurant').get();
      restaurantPriceMap.clear();
      for (var doc in restaurantSnapshot.docs) {
        var data = doc.data() as Map<String, dynamic>;
        restaurantPriceMap[data['RestaurantName'].toString()] = data['Price'].toString();
      }

      QuerySnapshot transportSnapshot = await FirebaseFirestore.instance.collection('Transport').get();
      transportPriceMap.clear();
      for (var doc in transportSnapshot.docs) {
        var data = doc.data() as Map<String, dynamic>;
        transportPriceMap[data['serviceName'].toString()] = data['price'].toString();
      }

      setState(() => isLoading = false);
    } catch (e) {
      if (kDebugMode) print('Error fetching dropdown data: $e');
      setState(() => isLoading = false);
    }
  }

  Future pickImage(int index) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);
      if (pickedFile != null) {
        if (kIsWeb) {
          final bytes = await pickedFile.readAsBytes();
          if (webImages.length <= index) webImages.length = index + 1;
          webImages[index] = bytes;
          if (selectedImages.length > index) selectedImages[index] = null;
        } else {
          if (selectedImages.length <= index) selectedImages.length = index + 1;
          selectedImages[index] = File(pickedFile.path);
          if (webImages.length > index) webImages[index] = null;
        }
        setState(() {});
      }
    } catch (e) {
      if (kDebugMode) print('Error picking image: $e');
    }
  }

  Future<String> uploadImageToImgBB({File? file, Uint8List? bytes}) async {
    final uri = Uri.parse("https://api.imgbb.com/1/upload?key=$imgBBApiKey");
    var request = http.MultipartRequest("POST", uri);

    if (kIsWeb && bytes != null) {
      request.files.add(http.MultipartFile.fromBytes('image', bytes, filename: "ticket.png"));
    } else if (!kIsWeb && file != null) {
      request.files.add(await http.MultipartFile.fromPath('image', file.path));
    } else {
      throw 'No image selected';
    }

    var response = await request.send();
    var resBody = await response.stream.bytesToString();
    var data = jsonDecode(resBody);

    if (response.statusCode == 200 && data["success"] == true) {
      return data["data"]["url"];
    } else {
      throw Exception("ImgBB Upload failed: ${data["error"]["message"]}");
    }
  }

  void showFlushBar(String message, Color color) {
    Flushbar(
      message: message,
      duration: const Duration(seconds: 3),
      backgroundColor: color,
      flushbarPosition: FlushbarPosition.TOP,
    ).show(context);
  }

  void clearForm() {
    _formKey.currentState!.reset();
    _providerController.clear();
    _destinationController.clear();
    _classController.clear();
    _priceController.clear();
    _departureDateController.clear();
    _returnDateController.clear();
    _typeController.clear();
    selectedHotel = null;
    selectedRestaurant = null;
    selectedTransport = null;
    selectedImages.clear();
    webImages.clear();
    updatingDoc = null;
    setState(() {});
  }

  void startUpdate(DocumentSnapshot doc) {
    _providerController.text = doc['Provider'];
    _destinationController.text = doc['Destination'];
    _classController.text = doc['Class'];
    _priceController.text = doc['Price'];
    _departureDateController.text = doc['DepartureDate'];
    _returnDateController.text = doc['ReturnDate'] ?? '';
    _typeController.text = doc['Type'];
    selectedHotel = doc['HotelName'];
    selectedRestaurant = doc['RestaurantName'];
    selectedTransport = doc['TransportName'];
    setState(() {
      updatingDoc = doc;
      selectedImages.clear();
      webImages.clear();
    });
  }

  void deleteTicket(String docId) async {
    bool confirm = await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Confirm Delete"),
        content: const Text("Are you sure you want to delete this ticket?"),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Cancel")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Delete")),
        ],
      ),
    );

    if (confirm) {
      await FirebaseFirestore.instance.collection('Tickets').doc(docId).delete();
      showFlushBar('Ticket deleted successfully', Colors.red);
    }
  }

  void submitForm() async {
    if (!_formKey.currentState!.validate()) return;
    if ((selectedImages.isEmpty && webImages.isEmpty && updatingDoc == null)) {
      showFlushBar("Please pick at least one image", Colors.orange);
      return;
    }

    try {
      String hotelPackage = selectedHotel != null ? hotelPackageMap[selectedHotel!] ?? '' : '';
      String restaurantPrice = selectedRestaurant != null ? restaurantPriceMap[selectedRestaurant!] ?? '' : '';
      String transportPrice = selectedTransport != null ? transportPriceMap[selectedTransport!] ?? '' : '';

      String? docId;
      if (updatingDoc != null) {
        docId = updatingDoc!.id;
        await FirebaseFirestore.instance.collection('Tickets').doc(docId).update({
          'Provider': _providerController.text.trim(),
          'Destination': _destinationController.text.trim(),
          'Class': _classController.text.trim(),
          'Price': _priceController.text.trim(),
          'DepartureDate': _departureDateController.text.trim(),
          'ReturnDate': _returnDateController.text.trim().isNotEmpty ? _returnDateController.text.trim() : null,
          'Type': _typeController.text.trim(),
          'HotelName': selectedHotel ?? '',
          'HotelPackage': hotelPackage,
          'RestaurantName': selectedRestaurant ?? '',
          'RestaurantPrice': restaurantPrice,
          'TransportName': selectedTransport ?? '',
          'TransportPrice': transportPrice,
        });
      } else {
        DocumentReference docRef = await FirebaseFirestore.instance.collection('Tickets').add({
          'Provider': _providerController.text.trim(),
          'Destination': _destinationController.text.trim(),
          'Class': _classController.text.trim(),
          'Price': _priceController.text.trim(),
          'DepartureDate': _departureDateController.text.trim(),
          'ReturnDate': _returnDateController.text.trim().isNotEmpty ? _returnDateController.text.trim() : null,
          'Type': _typeController.text.trim(),
          'HotelName': selectedHotel ?? '',
          'HotelPackage': hotelPackage,
          'RestaurantName': selectedRestaurant ?? '',
          'RestaurantPrice': restaurantPrice,
          'TransportName': selectedTransport ?? '',
          'TransportPrice': transportPrice,
          'TripImages': [],
          'created_at': FieldValue.serverTimestamp(),
        });
        docId = docRef.id;
      }

      // Upload images
      List<String> uploadedUrls = [];
      for (int i = 0; i < 5; i++) {
        if ((kIsWeb && i < webImages.length && webImages[i] != null) ||
            (!kIsWeb && i < selectedImages.length && selectedImages[i] != null)) {
          String url = await uploadImageToImgBB(
            file: (!kIsWeb && i < selectedImages.length) ? selectedImages[i] : null,
            bytes: (kIsWeb && i < webImages.length) ? webImages[i] : null,
          );
          uploadedUrls.add(url);
        }
      }

      if (uploadedUrls.isNotEmpty) {
        await FirebaseFirestore.instance.collection('Tickets').doc(docId).update({'TripImages': uploadedUrls});
      }

      showFlushBar(updatingDoc != null ? "Ticket updated successfully" : "Ticket added successfully", Colors.green);
      clearForm();
    } catch (e) {
      showFlushBar("Error: $e", Colors.red);
    }
  }

  Future<void> pickDate(TextEditingController controller) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      controller.text = "${picked.year}-${picked.month.toString().padLeft(2,'0')}-${picked.day.toString().padLeft(2,'0')}";
    }
  }

  Widget ticketRow(DocumentSnapshot doc) {
    List<dynamic> images = doc['TripImages'] ?? [];
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        title: Row(
          children: [
            const Icon(Icons.airplane_ticket, size: 18, color: Colors.blue),
            const SizedBox(width: 6),
            Expanded(child: Text(doc['Provider'], style: const TextStyle(fontWeight: FontWeight.bold))),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text("Destination: ${doc['Destination']}"),
            Text("Class: ${doc['Class']} | Price: ${doc['Price']}"),
            Text("Hotel: ${doc['HotelName']} | Restaurant: ${doc['RestaurantName']} | Transport: ${doc['TransportName']}"),
            if (images.isNotEmpty)
              SizedBox(
                height: 50,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: images.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 6),
                  itemBuilder: (context, index) => CircleAvatar(
                    radius: 20,
                    backgroundImage: NetworkImage(images[index]),
                  ),
                ),
              ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(icon: const Icon(Icons.edit, color: Colors.blue), onPressed: () => startUpdate(doc)),
            IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () => deleteTicket(doc.id)),
          ],
        ),
      ),
    );
  }

  Widget buildTextField(TextEditingController controller, String label, {IconData? icon}) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: icon != null ? Icon(icon) : null,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      ),
      validator: (val) => val!.isEmpty ? 'Enter $label' : null,
    );
  }

  Widget buildDateField(TextEditingController controller, String label, {bool optional = false}) {
    return TextFormField(
      controller: controller,
      readOnly: true,
      onTap: () => pickDate(controller),
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        suffixIcon: const Icon(Icons.calendar_today),
      ),
      validator: (val) {
        if (!optional && (val == null || val.isEmpty)) return 'Select $label';
        return null;
      },
    );
  }

  Widget buildDropdown(String label, List<String> items, String? selectedValue, Function(String?) onChanged) {
    return Material(
      color: Colors.white,
      child: DropdownButtonHideUnderline(
        child: DropdownButtonFormField<String>(
          value: selectedValue,
          hint: Text('Select $label'),
          items: items.isNotEmpty
              ? items.map((item) => DropdownMenuItem(value: item, child: Text(item))).toList()
              : [const DropdownMenuItem(value: null, child: Text("No data"))],
          onChanged: onChanged,
          decoration: InputDecoration(
            labelText: label,
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          ),
          validator: (val) => val == null ? 'Select $label' : null,
        ),
      ),
    );
  }

  Widget buildImagePickers() {
    return Wrap(
      spacing: 10,
      children: List.generate(5, (index) {
        ImageProvider? imgProvider;
        if (kIsWeb && index < webImages.length && webImages[index] != null) {
          imgProvider = MemoryImage(webImages[index]!);
        } else if (!kIsWeb && index < selectedImages.length && selectedImages[index] != null) {
          imgProvider = FileImage(selectedImages[index]!);
        }

        return InkWell(
          onTap: () => pickImage(index),
          child: CircleAvatar(
            radius: 25,
            backgroundColor: imgProvider == null ? Colors.blue : Colors.white,
            backgroundImage: imgProvider,
            child: imgProvider == null ? const Icon(Icons.add_a_photo, color: Colors.white) : null,
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue[50],
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Form(
                      key: _formKey,
                      child: Column(
                        children: [
                          buildTextField(_providerController, 'Provider', icon: Icons.person),
                          const SizedBox(height: 12),
                          buildTextField(_destinationController, 'Destination', icon: Icons.location_on),
                          const SizedBox(height: 12),
                          buildTextField(_classController, 'Class', icon: Icons.class_),
                          const SizedBox(height: 12),
                          buildTextField(_priceController, 'Price', icon: Icons.price_change),
                          const SizedBox(height: 12),
                          buildDateField(_departureDateController, 'Departure Date'),
                          const SizedBox(height: 12),
                          buildDateField(_returnDateController, 'Return Date (Optional)', optional: true),
                          const SizedBox(height: 12),
                          buildTextField(_typeController, 'Type', icon: Icons.local_offer),
                          const SizedBox(height: 12),
                          buildDropdown('Hotel', hotelPackageMap.keys.toList(), selectedHotel, (val) => setState(() => selectedHotel = val)),
                          const SizedBox(height: 12),
                          buildDropdown('Restaurant', restaurantPriceMap.keys.toList(), selectedRestaurant, (val) => setState(() => selectedRestaurant = val)),
                          const SizedBox(height: 12),
                          buildDropdown('Transport Service', transportPriceMap.keys.toList(), selectedTransport, (val) => setState(() => selectedTransport = val)),
                          const SizedBox(height: 16),
                          buildImagePickers(),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: submitForm,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            ),
                            child: Text(
                              updatingDoc != null ? "Update Ticket" : "Add Ticket",
                              style: const TextStyle(fontSize: 16, color: Colors.white),
                            ),
                          ),
                          if (updatingDoc != null)
                            IconButton(icon: const Icon(Icons.cancel, color: Colors.red), onPressed: clearForm),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance.collection('Tickets').orderBy('created_at', descending: true).snapshots(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState == ConnectionState.waiting) {
                          return const Center(child: CircularProgressIndicator());
                        }
                        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                          return const Center(child: Text("No Tickets Found"));
                        }
                        return ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: snapshot.data!.docs.length,
                          itemBuilder: (context, index) => ticketRow(snapshot.data!.docs[index]),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
