import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:another_flushbar/flushbar.dart';
import 'package:project/Components/AdminAppbar.dart';

class AddResturant extends StatefulWidget {
  const AddResturant({Key? key}) : super(key: key);

  @override
  _AddResturantState createState() => _AddResturantState();
}

class _AddResturantState extends State<AddResturant> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _foodTypeController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();

  bool isLoading = false;
  DocumentSnapshot? updatingDoc;

  void showFlushBar(String message, Color color) {
    Flushbar(
      message: message,
      duration: const Duration(seconds: 3),
      backgroundColor: color,
      flushbarPosition: FlushbarPosition.TOP,
    ).show(context);
  }

  Future<void> submitRestaurant() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      isLoading = true;
    });

    try {
      if (updatingDoc != null) {
        // Update
        await FirebaseFirestore.instance
            .collection('ManageRestaurant')
            .doc(updatingDoc!.id)
            .update({
          'RestaurantName': _nameController.text.trim(),
          'FoodType': _foodTypeController.text.trim(),
          'Price': double.parse(_priceController.text.trim()),
        });
        showFlushBar('Restaurant updated successfully', Colors.green);
      } else {
        // Add new
        await FirebaseFirestore.instance.collection('ManageRestaurant').add({
          'RestaurantName': _nameController.text.trim(),
          'FoodType': _foodTypeController.text.trim(),
          'Price': double.parse(_priceController.text.trim()),
          'createdAt': FieldValue.serverTimestamp(),
        });
        showFlushBar('Restaurant added successfully', Colors.green);
      }

      clearForm();
    } catch (e) {
      showFlushBar('Error: $e', Colors.red);
    }

    setState(() {
      isLoading = false;
    });
  }

  void clearForm() {
    _nameController.clear();
    _foodTypeController.clear();
    _priceController.clear();
    setState(() {
      updatingDoc = null;
    });
  }

  void startUpdate(DocumentSnapshot doc) {
    _nameController.text = doc['RestaurantName'];
    _foodTypeController.text = doc['FoodType'];
    _priceController.text = doc['Price'].toString();
    setState(() {
      updatingDoc = doc;
    });
  }

  void deleteRestaurant(String docId) async {
    bool confirm = await showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text("Confirm Delete"),
              content: const Text("Are you sure you want to delete this restaurant?"),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text("Cancel")),
                TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text("Delete")),
              ],
            ));

    if (confirm) {
      await FirebaseFirestore.instance.collection('ManageRestaurant').doc(docId).delete();
      showFlushBar('Restaurant deleted successfully', Colors.red);
    }
  }

  Widget restaurantRow(DocumentSnapshot doc) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: const Icon(Icons.restaurant_menu, size: 40, color: Colors.lightBlue),
        title: Text(doc['RestaurantName'], style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.fastfood, size: 16, color: Colors.lightBlue),
                const SizedBox(width: 4),
                Text("Food: ${doc['FoodType']}"),
              ],
            ),
            Row(
              children: [
                const Icon(Icons.attach_money, size: 16, color: Colors.lightBlue),
                const SizedBox(width: 4),
                Text("Price: ${doc['Price']}"),
              ],
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit, color: Colors.blue),
              onPressed: () => startUpdate(doc),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => deleteRestaurant(doc.id),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _foodTypeController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue[50],
      
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Form Section
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Restaurant Name',
                      prefixIcon: Icon(Icons.restaurant_menu),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) => val!.isEmpty ? 'Enter restaurant name' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _foodTypeController,
                    decoration: const InputDecoration(
                      labelText: 'Food Type',
                      prefixIcon: Icon(Icons.fastfood),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) => val!.isEmpty ? 'Enter food type' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _priceController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Price',
                      prefixIcon: Icon(Icons.attach_money),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) {
                      if (val == null || val.isEmpty) return 'Enter price';
                      if (double.tryParse(val) == null) return 'Enter a valid number';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: isLoading ? null : submitRestaurant,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.lightBlue,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          child: isLoading
                              ? const CircularProgressIndicator(color: Colors.white)
                              : Text(
                                  updatingDoc != null ? "Update Restaurant" : "Add Restaurant",
                                  style: const TextStyle(fontSize: 16, color: Colors.white),
                                ),
                        ),
                      ),
                      if (updatingDoc != null)
                        IconButton(
                            icon: const Icon(Icons.cancel, color: Colors.red),
                            onPressed: clearForm),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Heading for list
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: const [
                  Icon(Icons.restaurant_menu, color: Colors.black, size: 28),
                  SizedBox(width: 8),
                  Text(
                    "All Restaurants",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
            ),
            // List Section
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('ManageRestaurant')
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text("No Restaurants Found"));
                  }
                  return ListView(
                    children:
                        snapshot.data!.docs.map((doc) => restaurantRow(doc)).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
