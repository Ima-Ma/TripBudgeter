import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:another_flushbar/flushbar.dart';
import 'package:project/Components/AdminAppbar.dart';

class AddServices extends StatefulWidget {
  const AddServices({Key? key}) : super(key: key);

  @override
  _AddServicesState createState() => _AddServicesState();
}

class _AddServicesState extends State<AddServices> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _serviceNameController = TextEditingController();
  final TextEditingController _typeController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();

  final CollectionReference _transportCollection =
      FirebaseFirestore.instance.collection('Transport');

  bool isLoading = false;
  DocumentSnapshot? updatingDoc;

  void showFlushBar(String message, Color color) {
    Flushbar(
      message: message,
      duration: const Duration(seconds: 3),
      backgroundColor: color,
      flushbarPosition: FlushbarPosition.TOP,
    ).show(context);
  }

  Future<void> submitService() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      isLoading = true;
    });

    try {
      if (updatingDoc != null) {
        // Update
        await _transportCollection.doc(updatingDoc!.id).update({
          'serviceName': _serviceNameController.text.trim(),
          'type': _typeController.text.trim(),
          'price': double.parse(_priceController.text.trim()),
          'notes': _notesController.text.trim(),
        });
        showFlushBar('Service updated successfully', Colors.green);
      } else {
        // Add
        await _transportCollection.add({
          'serviceName': _serviceNameController.text.trim(),
          'type': _typeController.text.trim(),
          'price': double.parse(_priceController.text.trim()),
          'notes': _notesController.text.trim(),
          'createdAt': FieldValue.serverTimestamp(),
        });
        showFlushBar('Service added successfully', Colors.green);
      }

      clearForm();
    } catch (e) {
      showFlushBar('Error: $e', Colors.red);
    }

    setState(() {
      isLoading = false;
    });
  }

  void clearForm() {
    _serviceNameController.clear();
    _typeController.clear();
    _priceController.clear();
    _notesController.clear();
    setState(() {
      updatingDoc = null;
    });
  }

  void startUpdate(DocumentSnapshot doc) {
    _serviceNameController.text = doc['serviceName'];
    _typeController.text = doc['type'];
    _priceController.text = doc['price'].toString();
    _notesController.text = doc['notes'] ?? '';
    setState(() {
      updatingDoc = doc;
    });
  }

  void deleteService(String docId) async {
    bool confirm = await showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text("Confirm Delete"),
              content: const Text("Are you sure you want to delete this service?"),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text("Cancel")),
                TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text("Delete")),
              ],
            ));

    if (confirm) {
      await _transportCollection.doc(docId).delete();
      showFlushBar('Service deleted successfully', Colors.red);
    }
  }

  Widget serviceRow(DocumentSnapshot doc) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
      leading: const Icon(Icons.directions_car, size: 40, color: Colors.lightBlue),
        title: Text(doc['serviceName'], style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.directions_bus, size: 16, color: Colors.lightBlue),
                const SizedBox(width: 4),
                Text("Type: ${doc['type']}"),
              ],
            ),
            Row(
              children: [
                const Icon(Icons.attach_money, size: 16, color: Colors.lightBlue),
                const SizedBox(width: 4),
                Text("Price: ${doc['price']}"),
              ],
            ),
            if (doc['notes'] != null && doc['notes'] != '')
              Row(
                children: [
                  const Icon(Icons.note, size: 16, color: Colors.lightBlue),
                  const SizedBox(width: 4),
                  Expanded(
                      child: Text(
                    "Notes: ${doc['notes']}",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  )),
                ],
              ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit, color: Colors.blue),
              onPressed: () => startUpdate(doc),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => deleteService(doc.id),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _serviceNameController.dispose();
    _typeController.dispose();
    _priceController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue[50],
      
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Form Section
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _serviceNameController,
                    decoration: const InputDecoration(
                      labelText: 'Service Name',
                      prefixIcon: Icon(Icons.directions_car),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) => val!.isEmpty ? 'Enter service name' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _typeController,
                    decoration: const InputDecoration(
                      labelText: 'Type',
                      prefixIcon: Icon(Icons.category),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) => val!.isEmpty ? 'Enter type' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _priceController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Price',
                      prefixIcon: Icon(Icons.attach_money),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) {
                      if (val == null || val.isEmpty) return 'Enter price';
                      if (double.tryParse(val) == null) return 'Enter a valid number';
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _notesController,
                    decoration: const InputDecoration(
                      labelText: 'Notes',
                      prefixIcon: Icon(Icons.note),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: isLoading ? null : submitService,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.lightBlue,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          child: isLoading
                              ? const CircularProgressIndicator(color: Colors.white)
                              : Text(
                                  updatingDoc != null ? "Update Service" : "Add Service",
                                  style: const TextStyle(fontSize: 16, color: Colors.white),
                                ),
                        ),
                      ),
                      if (updatingDoc != null)
                        IconButton(
                            icon: const Icon(Icons.cancel, color: Colors.red),
                            onPressed: clearForm),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Heading
            Container(
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                children: const [
                  Icon(Icons.miscellaneous_services, color: Colors.black, size: 28),
                  SizedBox(width: 8),
                  Text(
                    "All Services",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
            ),
            // List
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: _transportCollection
                    .orderBy('createdAt', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text("No Services Found"));
                  }
                  return ListView(
                    children: snapshot.data!.docs.map((doc) => serviceRow(doc)).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
