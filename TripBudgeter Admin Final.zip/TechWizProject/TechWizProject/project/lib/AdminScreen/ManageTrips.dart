import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class ManageTrips extends StatefulWidget {
  const ManageTrips({Key? key}) : super(key: key);

  @override
  _ManageTripsState createState() => _ManageTripsState();
}

class _ManageTripsState extends State<ManageTrips> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Ensure 'status' exists in custom_reqs
  Future<void> _ensureStatus(DocumentSnapshot doc) async {
    final data = doc.data() as Map<String, dynamic>;
    if (!data.containsKey('status')) {
      await _firestore
          .collection('custom_reqs')
          .doc(doc.id)
          .update({'status': 'pending'});
    }
  }

  Widget _buildTripCard(Map<String, dynamic> data, String type,
      {String docId = ""}) {
    DateTime createdAt = (data['createdAt'] as Timestamp).toDate();
    String tripTitle = data['tripTitle'] ?? "-";
    String userEmail = data['userEmail'] ?? "-";
    int totalBill = data['totalBill'] ?? 0;
    List spots = data['spots'] ?? [];
    List points = data['points'] ?? [];
    String status = data['status'] ?? (type == 'Custom Request' ? "pending" : "-");

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      margin: const EdgeInsets.symmetric(vertical: 6),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "$tripTitle (${type.toUpperCase()})",
              style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.black87),
            ),
            const SizedBox(height: 4),
            Text("User: $userEmail"),
            Text(
                "Created: ${DateFormat('dd MMM yyyy, hh:mm a').format(createdAt)}"),
            Text("Total Bill: $totalBill"),
            Text("Status: $status"),
            const SizedBox(height: 4),
            if (spots.isNotEmpty) Text("Spots: ${spots.join(', ')}"),
            if (points.isNotEmpty) Text("Points: ${points.join(', ')}"),
            const SizedBox(height: 8),
            if (type == 'Custom Request' && status != 'approved')
              ElevatedButton(
                onPressed: () async {
                  await _firestore
                      .collection('custom_reqs')
                      .doc(docId)
                      .update({'status': 'approved'});
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                ),
                child: const Text("Approve" , style: TextStyle(color: Colors.white),),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCollectionStream(String collection, String type) {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore
          .collection(collection)
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return Center(child: Text("No $type found."));
        }

        // Ensure status exists for custom_reqs
        if (collection == 'custom_reqs') {
          for (var doc in docs) {
            _ensureStatus(doc);
          }
        }

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final data = docs[index].data() as Map<String, dynamic>;
            return _buildTripCard(
              data,
              type,
              docId: docs[index].id,
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Manage Trips Requests",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              _buildCollectionStream('booking_requests', 'Booking Request'),
              const SizedBox(height: 16),
              _buildCollectionStream('custom_reqs', 'Custom Request'),
            ],
          ),
        ),
      ),
    );
  }
}
