import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Contacts extends StatefulWidget {
  const Contacts({Key? key}) : super(key: key);

  @override
  _ContactsState createState() => _ContactsState();
}

class _ContactsState extends State<Contacts> {
  // function to show reply dialog
  Future<void> _showReplyDialog(DocumentSnapshot doc) async {
    final TextEditingController replyController = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Reply to Question"),
        content: TextField(
          controller: replyController,
          maxLines: 5,
          decoration: const InputDecoration(
            hintText: "Type your reply here...",
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () async {
              if (replyController.text.trim().isNotEmpty) {
                await FirebaseFirestore.instance
                    .collection("FAQs")
                    .doc(doc.id)
                    .update({
                  "reply": replyController.text.trim(),
                  "replyTimestamp": DateTime.now(),
                });
              }
              Navigator.pop(context);
            },
            child: const Text("Send Reply"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("  Manage Contacts and FAQs"   , style: TextStyle(color: Colors.white),),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('FAQs')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data!.docs;

          if (data.isEmpty) {
            return const Center(child: Text("No contacts found."));
          }

          return ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {
              final doc = data[index];
              final name = doc['name'] ?? '';
              final email = doc['email'] ?? '';
              final question = doc['question'] ?? '';
              final reply = doc.data().toString().contains('reply')
                  ? doc['reply']
                  : null; // ✅ safe check

              return Card(
                margin: const EdgeInsets.all(10),
                child: ListTile(
                  title: Text(
                    name,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Q: $question"),
                      Text("📧 $email"),
                      if (reply != null && reply.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            "Reply: $reply",
                            style: const TextStyle(
                              color: Colors.green,
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.reply, color: Colors.deepPurple),
                    onPressed: () => _showReplyDialog(doc),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
