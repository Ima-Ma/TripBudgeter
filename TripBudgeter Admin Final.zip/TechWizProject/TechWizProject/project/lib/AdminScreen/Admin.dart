import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_fonts/google_fonts.dart';

class Admin extends StatefulWidget {
  const Admin({Key? key}) : super(key: key);

  @override
  _AdminState createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  Widget _buildAnalyticsCard(String title, IconData icon, int count, Color color) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)), // smaller radius
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: color.withOpacity(0.2),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: GoogleFonts.poppins(
                        fontSize: 14, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0, end: count.toDouble()),
                  duration: const Duration(seconds: 1),
                  builder: (context, value, child) {
                    return Text(
                      value.toInt().toString(),
                      style: GoogleFonts.poppins(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCollectionCount(String collectionName, IconData icon, Color color) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection(collectionName).snapshots(),
      builder: (context, snapshot) {
        int count = snapshot.hasData ? snapshot.data!.docs.length : 0;
        return _buildAnalyticsCard(collectionName, icon, count, color);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> cards = [
      _buildCollectionCount("upcoming_trips", Icons.flight_takeoff, Colors.blue),
      _buildCollectionCount("points", Icons.location_on, Colors.orange),
      _buildCollectionCount("custom_reqs", Icons.note_alt, Colors.purple),
      _buildCollectionCount("FAQs", Icons.question_answer, Colors.green),
      _buildCollectionCount("booking_requests", Icons.shopping_bag, Colors.red),
    ];

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Admin Analytics"),
        centerTitle: true,

        backgroundColor: Colors.lightBlue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: GridView.builder(
          itemCount: cards.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, // 2 cards per row
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 2.2, // wider cards
          ),
          itemBuilder: (context, index) => cards[index],
        ),
      ),
    );
  }
}
