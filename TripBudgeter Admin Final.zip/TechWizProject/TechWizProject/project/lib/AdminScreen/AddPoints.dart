import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddPoints extends StatefulWidget {
  const AddPoints({Key? key}) : super(key: key);

  @override
  _AddPointsState createState() => _AddPointsState();
}

class _AddPointsState extends State<AddPoints> {
  final TextEditingController cityController = TextEditingController();
  final TextEditingController addressController = TextEditingController();

  String classType = "Business";
  String pointType = "Starting Point"; // ✅ new field

  final CollectionReference pointsRef =
      FirebaseFirestore.instance.collection('points');

  Future<void> addPoint() async {
    if (cityController.text.isEmpty || addressController.text.isEmpty) return;

    await pointsRef.add({
      'cityName': cityController.text,
      'address': addressController.text,
      'pointType': pointType, // ✅ save start/end
      'classType': classType,
      'createdAt': DateTime.now(),
    });

    clearFields();
  }

  Future<void> deletePoint(String id) async {
    await pointsRef.doc(id).delete();
  }

  void clearFields() {
    cityController.clear();
    addressController.clear();
    classType = "Business";
    pointType = "Starting Point";
    setState(() {});
  }

  Widget buildTextField(
      TextEditingController controller, IconData icon, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          prefixIcon: Icon(icon, color: Colors.lightBlue),
          labelText: label,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text("Manage Bus Points"  , style: TextStyle(color: Colors.white),),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      body: Column(
        children: [
          // 🔹 Form Section
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              children: [
                buildTextField(cityController, Icons.location_city, "City"),
                buildTextField(addressController, Icons.home, "Address"),

                // Point type dropdown (Start/End)
                DropdownButtonFormField<String>(
                  value: pointType,
                  items: ["Starting Point", "Ending Point"]
                      .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (val) => setState(() => pointType = val!),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.flag, color: Colors.lightBlue),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 10),

                // Class dropdown
                DropdownButtonFormField<String>(
                  value: classType,
                  items: ["Business", "Classic", "Others"]
                      .map((e) =>
                          DropdownMenuItem(value: e, child: Text(e)))
                      .toList(),
                  onChanged: (val) => setState(() => classType = val!),
                  decoration: InputDecoration(
                    prefixIcon:
                        const Icon(Icons.category, color: Colors.lightBlue),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 15),

                ElevatedButton.icon(
                  onPressed: addPoint,
                  icon: const Icon(Icons.add),
                  label: const Text("Add Point"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.lightBlue,
                    minimumSize: const Size(double.infinity, 45),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ],
            ),
          ),

          const Divider(),

          // 🔹 Data Section
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: pointsRef.orderBy("createdAt", descending: true).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                var docs = snapshot.data!.docs;

                if (docs.isEmpty) {
                  return const Center(
                      child: Text("No Points Added Yet",
                          style: TextStyle(fontSize: 16)));
                }

                return ListView.builder(
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    var data = docs[index].data() as Map<String, dynamic>;
                    String id = docs[index].id;

                    return Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      margin: const EdgeInsets.symmetric(
                          vertical: 6, horizontal: 10),
                      child: ListTile(
                        leading: const Icon(Icons.location_on,
                            color: Colors.lightBlue),
                        title: Text("${data['cityName']} - ${data['pointType']}"),
                        subtitle: Text(
                            "📍 ${data['address']}\nClass: ${data['classType']}"),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text("Delete Point"),
                                content: const Text(
                                    "Are you sure you want to delete this point?"),
                                actions: [
                                  TextButton(
                                      onPressed: () => Navigator.pop(context),
                                      child: const Text("Cancel")),
                                  ElevatedButton(
                                    onPressed: () {
                                      deletePoint(id);
                                      Navigator.pop(context);
                                    },
                                    style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.red),
                                    child: const Text("Delete"),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
