import 'dart:io';
import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:another_flushbar/flushbar.dart';
import 'package:project/Components/AdminAppbar.dart';

class AddHotel extends StatefulWidget {
  const AddHotel({Key? key}) : super(key: key);

  @override
  _AddHotelState createState() => _AddHotelState();
}

class _AddHotelState extends State<AddHotel> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _hotelNameController = TextEditingController();
  final TextEditingController _roomTypeController = TextEditingController();
  final TextEditingController _packageController = TextEditingController();
  final TextEditingController _facilitiesController = TextEditingController();

  File? selectedImage;
  Uint8List? webImage;
  final String imgBBApiKey = "90cb66237e5781971422bd58ed770554";

  final ImagePicker _picker = ImagePicker();
  DocumentSnapshot? updatingDoc;

  Future pickImage() async {
    try {
      if (kIsWeb) {
        final XFile? pickedFile =
            await _picker.pickImage(source: ImageSource.gallery);
        if (pickedFile != null) {
          final bytes = await pickedFile.readAsBytes();
          setState(() {
            webImage = bytes;
            selectedImage = null;
          });
        }
      } else {
        final XFile? pickedFile =
            await _picker.pickImage(source: ImageSource.gallery);
        if (pickedFile != null) {
          setState(() {
            selectedImage = File(pickedFile.path);
            webImage = null;
          });
        }
      }
    } catch (e) {
      if (kDebugMode) print('Error picking image: $e');
    }
  }

  Future<String> uploadImageToImgBB() async {
    final uri = Uri.parse("https://api.imgbb.com/1/upload?key=$imgBBApiKey");
    var request = http.MultipartRequest("POST", uri);

    if (kIsWeb && webImage != null) {
      request.files.add(http.MultipartFile.fromBytes(
        'image',
        webImage!,
        filename: "hotel.png",
      ));
    } else if (!kIsWeb && selectedImage != null) {
      request.files.add(await http.MultipartFile.fromPath(
        'image',
        selectedImage!.path,
      ));
    } else {
      throw Exception('No image selected');
    }

    var response = await request.send();
    var resBody = await response.stream.bytesToString();
    var data = jsonDecode(resBody);

    if (response.statusCode == 200 && data["success"] == true) {
      return data["data"]["url"];
    } else {
      throw Exception("ImgBB Upload failed: ${data["error"]["message"]}");
    }
  }

  void clearForm() {
    _hotelNameController.clear();
    _roomTypeController.clear();
    _packageController.clear();
    _facilitiesController.clear();
    setState(() {
      selectedImage = null;
      webImage = null;
      updatingDoc = null;
    });
  }

  void showFlushBar(String message, Color color) {
    Flushbar(
      message: message,
      duration: const Duration(seconds: 3),
      backgroundColor: color,
      flushbarPosition: FlushbarPosition.TOP,
    ).show(context);
  }

  Future<void> submitForm() async {
    if (!_formKey.currentState!.validate()) return;

    if (selectedImage == null && webImage == null && updatingDoc == null) {
      showFlushBar('Please pick an image', Colors.orange);
      return;
    }

    try {
      String? imageUrl;

      if (selectedImage != null || webImage != null) {
        imageUrl = await uploadImageToImgBB();
      } else if (updatingDoc != null) {
        imageUrl = updatingDoc!['HotelImage'];
      }

      if (updatingDoc != null) {
        // Update
        await FirebaseFirestore.instance
            .collection('ManageHotel')
            .doc(updatingDoc!.id)
            .update({
          'HotelName': _hotelNameController.text.trim(),
          'RoomType': _roomTypeController.text.trim(),
          'Package': _packageController.text.trim(),
          'Facilities': _facilitiesController.text.trim(),
          'HotelImage': imageUrl,
        });
        showFlushBar('Hotel updated successfully', Colors.green);
      } else {
        // Add new
        await FirebaseFirestore.instance.collection('ManageHotel').add({
          'HotelName': _hotelNameController.text.trim(),
          'RoomType': _roomTypeController.text.trim(),
          'Package': _packageController.text.trim(),
          'Facilities': _facilitiesController.text.trim(),
          'HotelImage': imageUrl,
          'created_at': FieldValue.serverTimestamp(),
        });
        showFlushBar('Hotel added successfully', Colors.green);
      }

      clearForm();
    } catch (e) {
      showFlushBar('Error: $e', Colors.red);
    }
  }

  void startUpdate(DocumentSnapshot doc) {
    _hotelNameController.text = doc['HotelName'];
    _roomTypeController.text = doc['RoomType'];
    _packageController.text = doc['Package'];
    _facilitiesController.text = doc['Facilities'];
    setState(() {
      updatingDoc = doc;
      selectedImage = null;
      webImage = null;
    });
  }

  void deleteHotel(String docId) async {
    bool confirm = await showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: const Text("Confirm Delete"),
              content:
                  const Text("Are you sure you want to delete this hotel?"),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text("Cancel")),
                TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text("Delete")),
              ],
            ));

    if (confirm) {
      await FirebaseFirestore.instance
          .collection('ManageHotel')
          .doc(docId)
          .delete();
      showFlushBar('Hotel deleted successfully', Colors.red);
    }
  }

  Widget hotelRow(DocumentSnapshot doc) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: doc['HotelImage'] != null && doc['HotelImage'] != ''
            ? ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(doc['HotelImage'], width: 60, height: 60, fit: BoxFit.cover),
              )
            : const Icon(Icons.hotel, size: 60, color: Colors.grey),
        title: Row(
          children: [
            const Icon(Icons.hotel, size: 16, color: Colors.blueGrey),
            const SizedBox(width: 4),
            Text(doc['HotelName'],
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Row(
              children: [
                const Icon(Icons.meeting_room, size: 16, color: Colors.blueGrey),
                const SizedBox(width: 4),
                Text("Room: ${doc['RoomType']}"),
              ],
            ),
            Row(
              children: [
                const Icon(Icons.card_giftcard, size: 16, color: Colors.blueGrey),
                const SizedBox(width: 4),
                Text("Package: ${doc['Package']}"),
              ],
            ),
  Row(
  children: [
    const Icon(Icons.checklist, size: 16, color: Colors.blueGrey),
    const SizedBox(width: 4),
    Expanded(
      child: Text(
        "Facilities: ${doc['Facilities']}",
        maxLines: 1, // Only 1 line
        overflow: TextOverflow.ellipsis, // Adds "..." if text is too long
      ),
    ),
  ],
),

          ],
        ),
        isThreeLine: true,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit, color: Colors.blue),
              onPressed: () => startUpdate(doc),
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.red),
              onPressed: () => deleteHotel(doc.id),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue[50],
     
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Form Section
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _hotelNameController,
                    decoration: const InputDecoration(
                      labelText: 'Hotel Name',
                      prefixIcon: Icon(Icons.hotel),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) =>
                        val!.isEmpty ? 'Enter Hotel Name' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _roomTypeController,
                    decoration: const InputDecoration(
                      labelText: 'Room Type',
                      prefixIcon: Icon(Icons.meeting_room),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) =>
                        val!.isEmpty ? 'Enter Room Type' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _packageController,
                    decoration: const InputDecoration(
                      labelText: 'Package',
                      prefixIcon: Icon(Icons.card_giftcard),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) =>
                        val!.isEmpty ? 'Enter Package' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _facilitiesController,
                    decoration: const InputDecoration(
                      labelText: 'Facilities',
                      prefixIcon: Icon(Icons.checklist),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                    ),
                    validator: (val) =>
                        val!.isEmpty ? 'Enter Facilities' : null,
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      InkWell(
                        onTap: pickImage,
                        child: CircleAvatar(
                          radius: 26,
                          backgroundColor: Colors.lightBlue,
                          backgroundImage: selectedImage != null
                              ? FileImage(selectedImage!)
                              : (webImage != null
                                  ? MemoryImage(webImage!)
                                  : null) as ImageProvider?,
                          child: (selectedImage == null && webImage == null)
                              ? const Icon(Icons.add_a_photo,
                                  color: Colors.white, size: 26)
                              : null,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: submitForm,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.lightBlue,
                            padding: const EdgeInsets.symmetric(
                                vertical: 16, horizontal: 20),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          child: Text(
                            updatingDoc != null ? "Update Hotel" : "Add Hotel",
                            style: const TextStyle(
                                fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                      if (updatingDoc != null)
                        IconButton(
                            icon: const Icon(Icons.cancel, color: Colors.red),
                            onPressed: clearForm),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Heading for list
    Container(
  alignment: Alignment.centerLeft,
  padding: const EdgeInsets.symmetric(vertical: 8),
  child: Row(
    children: const [
      Icon(Icons.hotel, color: Colors.black, size: 28),
      SizedBox(width: 8),
      Text(
        "All Hotels",
        style: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.bold,
          color: Colors.black87,
        ),
      ),
    ],
  ),
),

            // List Section
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('ManageHotel')
                    .orderBy('created_at', descending: true)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return const Center(child: Text("No Hotels Found"));
                  }
                  return ListView(
                    children:
                        snapshot.data!.docs.map((doc) => hotelRow(doc)).toList(),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
