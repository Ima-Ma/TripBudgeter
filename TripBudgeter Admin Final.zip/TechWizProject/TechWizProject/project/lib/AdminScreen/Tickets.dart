import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class Tickets extends StatefulWidget {
  const Tickets({Key? key}) : super(key: key);

  @override
  _TicketsState createState() => _TicketsState();
}

class _TicketsState extends State<Tickets> {
  final _formKey = GlobalKey<FormState>();

  String? selectedCity;
  List<String> selectedSpots = [];
  List<String> selectedPoints = [];
  String? selectedStartPoint;
  DateTime? startDate;
  DateTime? endDate;

  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _durationController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();

  // Cloudinary Config
  final String cloudName = "dlntmuhv5";
  final String uploadPreset = "tripsdata";

  List<String> uploadedImageUrls = [];

  // Pakistan cities with 5 spots each
  final Map<String, List<String>> citySpots = {
    "Lahore": [
      "Badshahi Mosque",
      "Lahore Fort",
      "Shalimar Gardens",
      "Minar-e-Pakistan",
      "Anarkali Bazaar",
    ],
    "Karachi": [
      "Clifton Beach",
      "Quaid-e-Azam Mausoleum",
      "Pakistan Maritime Museum",
      "Mohatta Palace",
      "Frere Hall",
    ],
    "Islamabad": [
      "Faisal Mosque",
      "Daman-e-Koh",
      "Pakistan Monument",
      "Lok Virsa Museum",
      "Rawal Lake",
    ],
    "Rawalpindi": [
      "Raja Bazaar",
      "Ayub National Park",
      "Rawalpindi Cricket Stadium",
      "Jinnah Park",
      "Liaquat Bagh",
    ],
    "Multan": [
      "Multan Fort",
      "Shrine of Shah Rukn-e-Alam",
      "Bahauddin Zakariya Shrine",
      "Ghanta Ghar",
      "Hussain Agahi Bazaar",
    ],
    "Faisalabad": [
      "Clock Tower (Ghanta Ghar)",
      "Jinnah Garden",
      "Lyallpur Museum",
      "D Ground",
      "Chenab Club",
    ],
    "Peshawar": [
      "Qissa Khwani Bazaar",
      "Bala Hisar Fort",
      "Peshawar Museum",
      "Sethi House",
      "Jamrud Fort",
    ],
    "Quetta": [
      "Hanna Lake",
      "Quaid-e-Azam Residency (Ziarat)",
      "Hazarganji Chiltan Park",
      "Quetta Museum",
      "Spin Karez",
    ],
    "Gilgit": [
      "Naltar Valley",
      "Rakaposhi View Point",
      "Kargah Buddha",
      "Gilgit Bridge",
      "Bagrot Valley",
    ],
    "Skardu": [
      "Shigar Fort",
      "Shangrila Lake",
      "Sheosar Lake",
      "Satpara Lake",
      "Deosai National Park",
    ],
    "Hunza": [
      "Attabad Lake",
      "Baltit Fort",
      "Altit Fort",
      "Eagle’s Nest",
      "Khunjerab Pass",
    ],
    "Murree": [
      "Mall Road",
      "Patriata (New Murree)",
      "Kashmir Point",
      "Pindi Point",
      "Changla Gali",
    ],
    "Naran": [
      "Lake Saif-ul-Malook",
      "Lalazar Plateau",
      "Babusar Top",
      "Dudipatsar Lake",
      "Kunhar River",
    ],
    "Swat": [
      "Malam Jabba",
      "Fizagat Park",
      "Miandam Valley",
      "Ushu Forest",
      "Mahodand Lake",
    ],
    "Neelum Valley": [
      "Kutton Waterfall",
      "Keran",
      "Sharda University Ruins",
      "Ratti Gali Lake",
      "Arang Kel",
    ],
  };

  // General highlights (points)
  final List<String> tripPoints = [
    "Sightseeing",
    "Cultural Visit",
    "Trekking",
    "Camping",
    "Boating",
    "Shopping",
    "Bonfire"
  ];

  /// ✅ Pick multiple images (Web + Mobile)
  Future<void> pickImages() async {
    final ImagePicker picker = ImagePicker();
    final List<XFile>? images = await picker.pickMultiImage(imageQuality: 80);

    if (images != null && images.isNotEmpty) {
      for (var img in images.take(5)) {
        String? url = await uploadToCloudinary(img);
        if (url != null) {
          setState(() {
            uploadedImageUrls.add(url);
          });
        }
      }
    } else {
      debugPrint("⚠ No images selected");
    }
  }

  /// ✅ Upload to Cloudinary (handles Web + Mobile)
  Future<String?> uploadToCloudinary(XFile image) async {
    final uri =
        Uri.parse("https://api.cloudinary.com/v1_1/$cloudName/image/upload");

    var request = http.MultipartRequest("POST", uri)
      ..fields['upload_preset'] = uploadPreset;

    if (kIsWeb) {
      // Web → upload using bytes
      var bytes = await image.readAsBytes();
      request.files.add(http.MultipartFile.fromBytes(
        'file',
        bytes,
        filename: image.name,
      ));
    } else {
      // Mobile → upload using file path
      request.files.add(await http.MultipartFile.fromPath('file', image.path));
    }

    var response = await request.send();
    if (response.statusCode == 200) {
      var res = await http.Response.fromStream(response);
      var data = jsonDecode(res.body);
      return data['secure_url'];
    } else {
      debugPrint("⚠ Upload failed: ${response.statusCode}");
      return null;
    }
  }

  /// Save Trip
  Future<void> addTrip() async {
    if (_formKey.currentState!.validate() &&
        startDate != null &&
        endDate != null &&
        selectedStartPoint != null &&
        uploadedImageUrls.isNotEmpty) {
      await FirebaseFirestore.instance.collection("upcoming_trips").add({
        "title": _titleController.text,
        "city": selectedCity,
        "duration": _durationController.text,
        "price": _priceController.text,
        "spots": selectedSpots,
        "points": selectedPoints,
        "startPoint": selectedStartPoint,
        "startDate": startDate,
        "endDate": endDate,
        "images": uploadedImageUrls,
        "createdAt": DateTime.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Trip Added Successfully!")),
      );

      _titleController.clear();
      _durationController.clear();
      _priceController.clear();

      setState(() {
        selectedCity = null;
        selectedSpots = [];
        selectedPoints = [];
        selectedStartPoint = null;
        startDate = null;
        endDate = null;
        uploadedImageUrls = [];
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all fields & add images")),
      );
    }
  }

  /// Pick Date
  Future<void> pickDate({required bool isStart}) async {
    DateTime now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          startDate = picked;
        } else {
          endDate = picked;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("  Manage & Add Pakistan Trip" , style: TextStyle(color: Colors.white),),
        centerTitle: true,
        backgroundColor: Colors.lightBlue,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(labelText: "Trip Title"),
                  validator: (v) => v!.isEmpty ? "Enter trip title" : null,
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _durationController,
                  decoration: const InputDecoration(labelText: "Duration"),
                  validator: (v) => v!.isEmpty ? "Enter duration" : null,
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _priceController,
                  decoration: const InputDecoration(labelText: "Price"),
                  keyboardType: TextInputType.number,
                  validator: (v) => v!.isEmpty ? "Enter price" : null,
                ),
                const SizedBox(height: 16),

                DropdownButtonFormField<String>(
                  decoration: const InputDecoration(
                    labelText: "Select City",
                    border: OutlineInputBorder(),
                  ),
                  value: selectedCity,
                  items: citySpots.keys.map((city) {
                    return DropdownMenuItem(
                      value: city,
                      child: Text(city),
                    );
                  }).toList(),
                  onChanged: (val) {
                    setState(() {
                      selectedCity = val;
                      selectedSpots = [];
                    });
                  },
                  validator: (val) =>
                      val == null ? "Please select a city" : null,
                ),
                const SizedBox(height: 16),

                MultiSelectDialogField(
                  items: (selectedCity != null && citySpots[selectedCity] != null)
                      ? citySpots[selectedCity]!
                          .map((e) => MultiSelectItem<String>(e, e))
                          .toList()
                      : [],
                  title: const Text("Select Spots"),
                  buttonText: const Text("Choose Spots"),
                  chipDisplay: MultiSelectChipDisplay(
                    chipColor: Colors.blue.shade100,
                    textStyle: const TextStyle(color: Colors.black),
                  ),
                  onConfirm: (values) {
                    setState(() {
                      selectedSpots = values.cast<String>();
                    });
                  },
                  initialValue: selectedSpots,
                ),
                const SizedBox(height: 16),

                MultiSelectDialogField(
                  items: tripPoints
                      .map((e) => MultiSelectItem<String>(e, e))
                      .toList(),
                  title: const Text("Select Highlights"),
                  buttonText: const Text("Choose Points"),
                  chipDisplay: MultiSelectChipDisplay(
                    chipColor: Colors.green.shade100,
                    textStyle: const TextStyle(color: Colors.black),
                  ),
                  onConfirm: (values) {
                    setState(() {
                      selectedPoints = values.cast<String>();
                    });
                  },
                  initialValue: selectedPoints,
                ),
                const SizedBox(height: 16),

              StreamBuilder<QuerySnapshot>(
  stream: FirebaseFirestore.instance.collection("points").snapshots(),
  builder: (context, snapshot) {
    if (!snapshot.hasData) {
      return const Center(child: CircularProgressIndicator());
    }
    var docs = snapshot.data!.docs;

    if (docs.isEmpty) {
      return const Text("⚠ No start points available in Firestore");
    }

    List<DropdownMenuItem<String>> items = docs.map((doc) {
      final data = doc.data() as Map<String, dynamic>;
      String name = "${data['cityName']} - ${data['address']}";
      return DropdownMenuItem(
        value: name,
        child: SizedBox(
          width: MediaQuery.of(context).size.width * 0.7, // limit width
          child: Text(
            name,
            overflow: TextOverflow.ellipsis, // add ... if too long
            softWrap: true,
          ),
        ),
      );
    }).toList();

    return DropdownButtonFormField<String>(
      decoration: const InputDecoration(
        labelText: "Select Start Point",
        border: OutlineInputBorder(),
      ),
      value: selectedStartPoint,
      items: items,
      onChanged: (val) {
        setState(() {
          selectedStartPoint = val;
        });
      },
      validator: (val) =>
          val == null ? "Please select a start point" : null,
    );
  },
),
    const SizedBox(height: 16),

                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    ElevatedButton(
                      onPressed: () => pickDate(isStart: true),
                      child: Text(startDate == null
                          ? "Select Start Date"
                          : "Start: ${startDate!.toLocal()}".split(' ')[0]),
                    ),
                    ElevatedButton(
                      onPressed: () => pickDate(isStart: false),
                      child: Text(endDate == null
                          ? "Select End Date"
                          : "End: ${endDate!.toLocal()}".split(' ')[0]),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                ElevatedButton.icon(
                  onPressed: pickImages,
                  icon: const Icon(Icons.photo_library),
                  label: const Text("Select Images (Max 5)"),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: uploadedImageUrls
                      .map((url) => ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.network(url,
                                width: 80, height: 80, fit: BoxFit.cover),
                          ))
                      .toList(),
                ),
                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: addTrip,
                    child: const Text("Add Trip"),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
