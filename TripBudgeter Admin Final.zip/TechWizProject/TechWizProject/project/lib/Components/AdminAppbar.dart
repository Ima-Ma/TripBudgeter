import 'package:flutter/material.dart';

class AdminAppbar extends StatelessWidget implements PreferredSizeWidget {
  const AdminAppbar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.lightBlue, // Light Blue color
      elevation: 2,
      centerTitle: true,
      leading: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Image.asset(
          'assets/whiteicon.png', // Your logo
          fit: BoxFit.contain,
        ),
      ),
      title: const Text(
        "Admin Dashboard",
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
      // actions: [
      //   IconButton(
      //     onPressed: () {
      //       // TODO: handle notifications
      //     },
      //     icon: const Icon(Icons.notifications, color: Colors.white),
      //   ),
      //   IconButton(
      //     onPressed: () {
      //       // TODO: handle logout
      //     },
      //     icon: const Icon(Icons.logout, color: Colors.white),
      //   ),
      // ],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
